  {{-- <div class="preloader js-preloader">
      <div class="preloader__wrap">
          <div class="preloader__icon">
              <img src="{{ url('assets/images/logo.png') }}" alt="Blessing 89 Logo" width="80" height="80"
                  style="object-fit: contain;">
          </div>
      </div>

      <div class="preloader__title">....</div>
  </div> --}}
